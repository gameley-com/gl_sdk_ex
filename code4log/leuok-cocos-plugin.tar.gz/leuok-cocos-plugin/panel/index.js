// panel/index.js, this filename needs to match the one registered in package.json
Editor.Panel.extend({
  // css style for panel
  style: `
    :host { margin: 5px; }
    h2 { color: #f90; text-align: center; }
    label {
      display: inline-block;
      width: 200px;
      margin-left: 20px;
    }
    #bi-btn {
      position: absolute;
      width: 100px;
      right: 20px;
    }
    .desc-title {
      color:tomato;
    }
  `,

  // html template for panel
  template: `
    <h2>${Editor.T('bi.app')}配置</h2>
    <p>
      <label for="bi-game">游戏ID</label>
      <input id="bi-game" v-model="buildConfig.gameId"/>
    </p>
    
    <p>
      <label>微信appId</label>
      <input v-model="buildConfig.appId"/>
      <span class="desc-title">仅构建微信时需要</span>
    </p>

    <p>
      <label for="bi-adlog">是否发送adlog</label>
      <input type="checkbox" id="bi-adlog" v-model="buildConfig.adlog">
      <span class="desc-title">仅构建微信时需要,单独接入过请去掉勾选</span>
    </p>

    <p>
      <label for="bi-env">环境</label>
      <select id="bi-env" v-model="buildConfig.env">
        <option value="dev">测试</option>
        <option value="prod">正式</option>
      </select>
    </p>

    <p>
      <label for="bi-h5">H5类型</label>
      <select id="bi-h5" v-model="buildConfig.h5Type">
        <option value="qqh5">H5 QQ</option>
        <option value="oppoh5">H5 OPPO</option>
        <option value="qzone">H5 QZONE</option>
      </select>
      <span class="desc-title">仅构建H5应用时需要</span>
    </p>
    
    <p>
      <label for="bi-version">SDK版本</label>
      <select id="bi-version" v-model="buildConfig.version">
        <option v-for="item in buildConfig.packageInfo.versions" value="{{item.version}}" v-if="!item.deprecated">{{item.version}}</option>
      </select>
    </p>

    <p>
      <label for="bi-multiRegion">是否为多区服(滚服)游戏</label>
      <input type="checkbox" id="bi-multiRegion" v-model="buildConfig.multiRegion" @click="multiRegionChange">
    </p>

    <p>
      <label for="bi-log">开启日志输出</label>
      <input type="checkbox" id="bi-log" v-model="buildConfig.log">
    </p>

    <p>
      <label for="bi-used">是否启用插件注入SDK</label>
      <input type="checkbox" id="bi-used" v-model="buildConfig.used">
    </p>
    
    <hr />
    <ui-button class="green" id="bi-btn" @confirm="onConfirm">确定</ui-button>
  `,


  // method executed when template and styles are successfully loaded and initialized
  ready() {
    // this.$biBtn.addEventListener('click', () => {
    //   Editor.Ipc.sendToMain('bi:bi-used-changed', {
    //     game: this.$biGame.value,
    //     region: this.$biRegion.value,
    //     env: this.$biEnv.value,
    //     h5Type: this.$biH5.value,
    //     used: this.$biUsed.checked
    //   })
    // });
  },

  run(data) {
    if (!data.version) {
      data.version = data.packageInfo.distTags.latest
    }

    if (!data.packageInfo.versions.hasOwnProperty(data.version) || data.packageInfo.versions[data.version].deprecated) {
      alert(`当前SDK版本[${data.version}]已废弃, 请重新选择合适版本(已默认选择最新版本,点击确定启用)`)
      data.version = data.packageInfo.distTags.latest
    }

    new window.Vue({
      el: this.shadowRoot,
      data: {
        buildConfig: data
      },
      methods: {
        onConfirm () {
          if (this.buildConfig.used) {
            if (!this.buildConfig.gameId) {
              alert('游戏ID不能为空')
              return
            }
          }
          if (!data.packageInfo.versions.hasOwnProperty(data.version)) {
            alert(`当前SDK版本[${data.version}]已废弃, 请重新选择合适版本`)
            return
          }

          Editor.Ipc.sendToMain('bi:bi-used-changed', this.buildConfig)
        },
        multiRegionChange() {
          if (!this.buildConfig.multiRegion) {
            alert("多区服(滚服)游戏需要在调用方法时自行传递regionId")
          }
        }
      },
    });
  }
});