module.exports = {
    'app': 'LEUOK日志配置'
}