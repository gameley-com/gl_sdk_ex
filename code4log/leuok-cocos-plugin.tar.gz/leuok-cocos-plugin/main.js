'use strict';

const https = require('https')
const path = require('path')
const fs = require('fs')
const crypto = require('crypto')


function getBuildConfig() {
  try {
    let settingPath = path.join(Editor.Project.path || Editor.projectPath, 'settings', 'bi-sdk-plugin.json')
    return JSON.parse(fs.readFileSync(settingPath, 'utf8'))
  } catch (error) {
    return {
      gameId: 1,
      appId: '',
      h5Type: 'qqh5',
      multiRegion: false,
      used: false,
      adlog: true,
      env: 'dev',
      log: true
    }
  }
}

function request(url, dataType = 'string') {
  return new Promise((resolve, reject) => {
    https.get(url, (res) => {
      let data = ''
      res.on('data', (chunk) => {
        data += chunk
      })
      res.on('end', () => {
        if (dataType === 'json') {
          try {
            let jsonData = JSON.parse(data)
            resolve(jsonData)
            return
          } catch (e) {}
        }
        resolve(data)
      })
    }).on("error", (err) => {
      reject(err)
    })
  })
}

// 初始化脚本
function getInitScript(platType, buildConfig, md5Code = '') {
  // 不同平台 全局变量名称
  let sdkGlobalMap = new Map([
    ['qqh5', 'window'],
    ['qzone', 'window'],
    ['oppoh5', 'window'],
    ['vivo', 'qg'],
    ['oppo', 'qg'],
    ['qq', 'BK'],
    ['wx', 'wx']
  ])

  // 微信需要配置推广信息
  let appIdScrint = platType === 'wx' ? `appId: '${buildConfig.appId}', adlog: ${buildConfig.adlog}, ` : ''

  let headerStart = `
// ===================BISDK-BEGIN======================

/**
 * Copyright ${new Date().getFullYear()} The Gameley-TC Authors. 
 * All rights reserved.
 * BISDK INIT
 */
`
  let headerEnd = '\n// =====================BISDK-END=======================\n'

  let initConfig = `${sdkGlobalMap.get(platType)}.leuok.init({ gameId: ${buildConfig.gameId}, env: '${buildConfig.env}', log: ${buildConfig.log}, ${appIdScrint}});`

  if (platType === 'qqh5') {
    return `
${headerStart}
new window.Game({
  onLoad: function (app) {
    ${initConfig}
  },
});
${headerEnd}
`}

  if (platType === 'qq') {
    return `
${headerStart}
new BK.Game({
  onLoad: function (app) {
    ${initConfig}
  },
});
${headerEnd}
`}

  if (['oppoh5', 'qzone'].includes(platType)) {
    return `<script src="leuok.bi.${platType}.${md5Code}.js" charset="utf-8"></script>`
  }

  // 快游戏需要在登陆后自行初始化
  if (['oppo', 'vivo'].includes(platType)) {
    return ''
  }

  return `
${headerStart}
${initConfig}
${headerEnd}
`}

async function getSdk(plat, version) {
  // Editor.log('LEUOK', '查询SDK版本')
  // let packageVersion = await request('https://registry.npm.taobao.org/@gameley/bi', 'json')
  // let latestVersion = packageVersion['dist-tags'].latest || 'latest'
  let packageInfo = await request('https://registry.npm.taobao.org/@gameley/bi', 'json')
  if (packageInfo.versions.hasOwnProperty(version) && !packageInfo.versions[version].deprecated) {
    Editor.log('LEUOK', 'start download sdk version', version, `https://cdn.jsdelivr.net/npm/@gameley/bi@${version}/dist/leuok.bi.${plat}.js`)
    return request(`https://cdn.jsdelivr.net/npm/@gameley/bi@${version}/dist/leuok.bi.${plat}.js`)
  }
  Editor.Ipc.sendToMain('bi:open')
  throw { message: `当前版本SDK[${version}]已被废弃, 请在插件配置里重新选择合适的SDK版本` }
}


async function onBeforeBuildFinish(options, callback) {

  let pluginVersion = JSON.parse(fs.readFileSync(path.join(__dirname, 'package.json'), 'utf8')).version
  Editor.log('LEUOK', 'plugin version', pluginVersion)


  let buildConfig = getBuildConfig()

  //  根据平台类型  获取队形sdk
  let sdkMap = new Map([
    ['web-mobile', 'h5'],
    ['vivo-runtime', 'vivo'],
    ['oppo-runtime', 'oppo'],
    ['qqplay', 'qq'],
    ['quickgame', 'oppo'],
    ['qgame', 'vivo'],
      ['wechatgame', 'wx'],
  ])

  let platType = sdkMap.get(options.actualPlatform || options.platform)
  Editor.log('LEUOK', 'platType:'+platType)

  if (!platType) {
    Editor.error('LEUOK', 'could not found platform --->')
    callback()
    return
  }

  if (platType === 'h5') {
    platType = buildConfig.h5Type
  }

  // 同步 jsdelivr cdn sdk文件
  Editor.log('LEUOK', 'start build and inject sdk')

  let sdkMd5 = ''

  try {
    let sdkStr = await getSdk(platType, buildConfig.version)
    Editor.log('LEUOK', 'sdk download success')
    // h5qq 初始化写在sdk文件最后
    if (['qqh5', 'qq', 'wx'].includes(platType)) {
      sdkStr += getInitScript(platType, buildConfig)
    }

    let hash = crypto.createHash('md5')
    hash.update(sdkStr)
    sdkMd5 = hash.digest('hex').slice(0, 5)
    if (['vivo', 'oppo'].includes(platType)) {
      let mainJsPath = path.join(options.dest, 'main.js')
      let script = fs.readFileSync(mainJsPath, 'utf8')
      fs.writeFile(mainJsPath, sdkStr + '\n\n' + script)
      callback()
      return
    }

    let md5Name = options.md5Cache ? '' : `.${sdkMd5}`
    let sdkFileName = `leuok.bi.${platType}${md5Name}.js`
    // qq wx web 存储为文件单独引入
    fs.writeFile(path.join(options.dest, sdkFileName), sdkStr, (err) => {
      if (err) {
        Editor.error('LEUOK', '创建SDK文件失败 -->', err)
        callback()
        return
      }
    })
  } catch (err) {
    Editor.error('LEUOK', '获取远程SDK文件失败 -->', err.message)
    callback()
    return
  }

  // 如果是web app 修改 index.html
  if (platType.includes('h5')) {
    let fileBuffer = fs.readFileSync(path.join(options.dest, 'index.html'), 'utf8')
    let fileLines = fileBuffer.toString().split('\n')

    let targetIndex = fileLines.findIndex((val, index, arr) => {
      return val.includes('<script src="main')
    })

    if (platType === 'qqh5') {
      let qqh5TargetIndex = fileLines.findIndex((val, index, arr) => {
        return val.includes('<script src="qqPlayCore')
      })
      if (qqh5TargetIndex === -1) {
        Editor.warn('LEUOK', 'h5QQ请先在build-templates配置好引入qqPlayCore.js')
      } else {
        targetIndex = qqh5TargetIndex
      }

      fileLines.splice(targetIndex + 1, 0, `<script src="leuok.bi.${platType}.${sdkMd5}.js" charset="utf-8"></script>`)
    } else {
      fileLines.splice(targetIndex, 0, getInitScript(platType, buildConfig, sdkMd5))
    }

    // 写入文件
    fs.writeFile(path.join(options.dest, 'index.html'), fileLines.join('\n'), (err) => {
      if (err) {
        Editor.error('LEUOK', '修改index.html失败 -->', err)
      }
    })
    callback()
    return
  }

  // for qq wx 
  let entryFile = platType === 'wx' ? 'game.js' : 'main.js'
  let mainJsPath = path.join(options.dest, entryFile)
  let script = fs.readFileSync(mainJsPath, 'utf8')

  if (platType === 'qq') {
    fs.writeFileSync(mainJsPath, script + `BK.Script.loadlib('GameRes://leuok.bi.qq.${sdkMd5}.js');`)
  }

  if (platType === 'wx') {
    fs.writeFileSync(mainJsPath, `require('leuok.bi.wx.${sdkMd5}');\n` + script)
  }

  Editor.log('LEUOK', 'success inject sdk in main.js or game.js')
  // 对于 快游戏(oppo, vivo) 在获取sdk时处理 直接合并进入main.js

  callback()
}


module.exports = {
  load() {
    let buildConfig = getBuildConfig()
    if (buildConfig.used) {
      Editor.log('LEUOK', '开启构建后添加SDK')
      Editor.Builder.on('before-change-files', onBeforeBuildFinish)
    }
    // execute when package loaded
  },

  unload() {
    // execute when package unloaded
    Editor.log('LEUOK', '关闭构建后添加SDK')
    Editor.Builder.removeListener('before-change-files', onBeforeBuildFinish)
  },

  // register your ipc messages here
  messages: {
    'bi-used-changed'(event, config, isClose = true) {
      Editor.Panel.close('bi')
      delete config.versions
      delete config.packageInfo
      let buildConfig = getBuildConfig()
      // 判断是否在load时已开启监听
      if (buildConfig.used !== config.used) {
        if (config.used) {
          Editor.log('LEUOK', '开启构建后添加SDK')
          Editor.Builder.on('before-change-files', onBeforeBuildFinish)
        } else {
          Editor.log('LEUOK', '关闭构建后添加SDK')
          Editor.Builder.removeListener('before-change-files', onBeforeBuildFinish)
        }
      } else {
        if (config.used) {
          Editor.log('LEUOK', '开启构建后添加SDK')
        } else {
          Editor.log('LEUOK', '关闭构建后添加SDK')
        }
      }

      let settingPath = path.join(Editor.Project.path || Editor.projectPath, 'settings', 'bi-sdk-plugin.json')
      fs.writeFile(settingPath, JSON.stringify(config, null, 4), (err) => {
        if (err) {
          Editor.error('LEUOK', '生成配置文件失败', err.message)
        }
      })

    },
    async open() {
      // open entry panel registered in package.json
      let packageInfo = await request('https://registry.npm.taobao.org/@gameley/bi', 'json')
      let buildConfig = getBuildConfig()
      if (buildConfig.adlog === undefined) {
        buildConfig.adlog = true
      }
      // buildConfig.versions = []
      // for (const i in packageInfo.versions) {
      //   if (!packageInfo.versions[i].deprecated) {
      //     buildConfig.versions.push(packageInfo.versions[i].version)
      //   }
      // }
      // buildConfig.disTag = packageInfo['dist-tags']

      buildConfig.packageInfo = { versions: packageInfo.versions, distTags: packageInfo['dist-tags'] }
      Editor.Panel.open('bi', buildConfig)
    }
  },
};